function getInputFromTextBox() {
    var input = document. getElementById("userInput"). value;
    alert(input);
    }
    