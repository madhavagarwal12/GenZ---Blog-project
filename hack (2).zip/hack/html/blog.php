<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style/create.css/contact.css">
    <link rel="stylesheet" href="/style/create.css/mobile.css">
    <link rel="stylesheet" href="/style/create.css/style.css">
    <link rel="stylesheet" href="/style/create.css/utils.css">
    <title>create</title>
</head>

<body>
    <nav class="navigation max-width-1 m-auto">
        <div class="nav-left">
            <a href="/">
                <span><img src="img/logo.png" width="94px" alt=""></span>
            </a>
            <ul>
                <li><a href="/html/home.html">Home</a></li>
                <li><a href="#">About me</a></li>
                <li><a href="/html/create.html">Create</a></li>
            </ul>
        </div>
        <div class="nav-right">
            <form action="/html/explore.html" method="get">
                <input class="form-input" type="text" name="query" placeholder="Blog Search">
                <button class="btn">Search</button>
            </form>

        </div>

    </nav>
    <div class="max-width-1 m-auto">
        <hr>
    </div>
    <div class="contact-content font1 max-width-1 m-auto">
        <div class="max-width-1 m-auto mx-1">
            <h2>Feel Free to share your thoughts</h2>
            <div class="contact-form">
                <div class="form-box">
                    <input type="text" id="id" placeholder="Enter Your id">
                </div>
                <div class="form-box">
                    <input type="text" id="head" placeholder="Enter Your content heading">
                </div>
                <div class="form-box">
                    <input type="text" id="sdiscription" placeholder="Enter short description">
                </div>
                <div class="form-box">
                    <textarea name="" id="content" cols="30" rows="10" placeholder="start typing your content"></textarea>
                </div>
                <div class="form-box">
                    <button class="btn">Submit</button>
                </div>

            </div>
        </div>

    </div>




    <div class="footer">
        
        <p>Vector Credits: Vecteezy</p>
    </div>
<!-- Code injected by live-server -->
<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>

</html>